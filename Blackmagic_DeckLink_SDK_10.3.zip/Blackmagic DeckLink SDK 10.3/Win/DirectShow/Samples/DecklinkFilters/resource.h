//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DecklinkFilters.rc
//
#define VERSION_RES_MINOR_VER           0
#define VERSION_RES_BUILD               0
#define VER_DEBUG                       0
#define VERSION_RES_MAJOR_VER           9
#define IDD_DECKLINK_COMPOSITE_PROPPAGE 102
#define IDS_DECKLINK_COMPOSITE_PROPNAME 103
#define IDC_EDIT_WIDTH                  1002
#define IDC_EDIT_WIDTH2                 1003
#define IDC_EDIT_HEIGHT                 1003
#define VERSION_RES_LANGUAGE            0x409
#define VERSION_RES_CHARSET             1252
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
